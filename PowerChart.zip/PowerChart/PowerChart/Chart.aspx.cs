﻿using System;
using System.Collections;
using System.Web.Services;

namespace PowerChart
{
    public partial class Chart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static ArrayList GetIndividualMeter()
        {
            return new ArrayList()
            {
                new { Value = 1, Display = "Meter1" },
                new { Value = 2, Display = "Meter2" },
                new { Value = 3, Display = "Meter3" },
                new { Value = 4, Display = "Meter4" },
                new { Value = 5, Display = "Meter5" },
                new { Value = 6, Display = "Meter6" },
                new { Value = 7, Display = "Meter7" },
                new { Value = 8, Display = "Meter8" },
                new { Value = 9, Display = "Meter9" },
                new { Value = 10, Display = "Meter10" }

            };
        }

        [WebMethod]
        public static ArrayList GetGroupMeter()
        {
            return new ArrayList()
            {
                new { Value = 1, Display = "GroupMeter1" },
                new { Value = 2, Display = "GroupMeter2" },
                new { Value = 3, Display = "GroupMeter3" },
                new { Value = 4, Display = "GroupMeter4" },
                new { Value = 5, Display = "GroupMeter5" },
                new { Value = 6, Display = "GroupMeter6" },
                new { Value = 7, Display = "GroupMeter7" },
                new { Value = 8, Display = "GroupMeter8" },
                new { Value = 9, Display = "GroupMeter9" },
                new { Value = 10, Display = "GroupMeter10" }

            };
        }
    }
}