﻿using System;
using Microsoft.AspNet.SignalR;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace PowerChart
{
    public class MeterDetails
    {
        public bool IsIndividual { get; set; }
        public bool IsGroup { get; set; }
        public string MeterNo { get; set; }
        public string MeterName { get; set; }
        public bool IsGroup1 { get; set; }
        public bool IsGroup2 { get; set; }
        public bool IsGroup3 { get; set; }
        public long Attribute1 { get; set; }
        public long Attribute2 { get; set; }
        public long Attribute3 { get; set; }
        public long Attribute4 { get; set; }
        public bool IsChartType1 { get; set; }
        public bool IsChartType2 { get; set; }
        public bool IsChartType3 { get; set; }
        public long ChartType1 { get; set; }
        public long ChartType2 { get; set; }
        public long ChartType3 { get; set; }
        public DateTime ChartType1Time { get; set; }
        public DateTime ChartType2Time { get; set; }
        public DateTime ChartType3Time { get; set; }

        public MeterDetails()
        {
        }

        public MeterDetails(MeterDetails m)
        {
            this.IsIndividual = m.IsIndividual;
            this.IsGroup = m.IsGroup;
            this.MeterNo = m.MeterNo;
            this.MeterName = m.MeterName;
            this.IsGroup1 = m.IsGroup1;
            this.IsGroup2 = m.IsGroup2;
            this.IsGroup3 = m.IsGroup3;
            this.Attribute1 = m.Attribute1;
            this.Attribute2 = m.Attribute2;
            this.Attribute3 = m.Attribute3;
            this.Attribute4 = m.Attribute4;
            this.IsChartType1 = m.IsChartType1;
            this.IsChartType2 = m.IsChartType2;
            this.IsChartType3 = m.IsChartType3;
            this.ChartType1 = m.ChartType1;
            this.ChartType2 = m.ChartType2;
            this.ChartType3 = m.ChartType3;
            this.ChartType1Time = m.ChartType1Time;
            this.ChartType2Time = m.ChartType2Time;
            this.ChartType3Time = m.ChartType3Time;
        }

    }

    public class ChartHub : Hub
    {
        public void Send(string obj)
        {
            MeterDetails m = JsonConvert.DeserializeObject<MeterDetails>(obj);
            Random r = new Random();
            m.Attribute1 = r.Next(100, 1000);
            m.Attribute2 = r.Next(100, 1000);
            m.Attribute3 = r.Next(100, 1000);
            m.Attribute4 = r.Next(100, 1000);

            MeterDetails detailsTemp = new MeterDetails(m);

            var TaskA = Task.Factory.StartNew(() => GetChartType1(ref m));
            var TaskB = Task.Factory.StartNew(() => GetChartType2(ref m));
            var TaskC = Task.Factory.StartNew(() => GetChartType3(ref m));
            DateTime dt = DateTime.Now;
            if (!TaskA.Wait(10000) && m.IsChartType1)
            {
                m.ChartType1 = detailsTemp.ChartType1;
                m.ChartType1Time = detailsTemp.ChartType1Time;
            }
            else
            {
                m.ChartType1Time = dt;
            }

            if (!TaskB.Wait(10000) && m.IsChartType2)
            {
                m.ChartType2 = detailsTemp.ChartType2;
                m.ChartType2Time = detailsTemp.ChartType2Time;
            }
            else
            {
                m.ChartType2Time = dt;
            }

            if (!TaskC.Wait(10000) && m.IsChartType3)
            {
                m.ChartType3 = detailsTemp.ChartType3;
                m.ChartType3Time = detailsTemp.ChartType3Time;
            }
            else
            {
                m.ChartType3Time = dt;
            }

            Clients.All.broadcastMessage(m);
        }

        private void GetChartType1(ref MeterDetails details)
        {
            if (details.IsIndividual)
            {
                details.ChartType1 = new Random().Next(100, 1000);
            }
            else if (details.IsGroup)
            {
                if (details.IsGroup1)
                {
                    details.ChartType1 = new Random().Next(100, 1000) + new Random().Next(100, 1000) + new Random().Next(100, 1000) + new Random().Next(100, 1000);
                }
                else if (details.IsGroup2)
                {
                    details.ChartType1 = new Random().Next(100, 1000) + new Random().Next(100, 1000) + new Random().Next(100, 1000) + new Random().Next(100, 1000) + new Random().Next(100, 1000);
                }
                else if (details.IsGroup3)
                {
                    details.ChartType1 = new Random().Next(100, 1000) + new Random().Next(100, 1000) + new Random().Next(100, 1000) + new Random().Next(100, 1000) + new Random().Next(100, 1000) + new Random().Next(100, 1000);
                }
            }
            //if (details.ChartType1 % 10 == 0)
            //{
            //    System.Threading.Thread.Sleep(1000);
            //}
        }

        private void GetChartType2(ref MeterDetails details)
        {
            if (details.IsIndividual)
            {
                details.ChartType2 = new Random().Next(100, 2000);
            }
            else if (details.IsGroup)
            {
                if (details.IsGroup1)
                {
                    details.ChartType2 = new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000);
                }
                else if (details.IsGroup2)
                {
                    details.ChartType2 = new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000);
                }
                else if (details.IsGroup3)
                {
                    details.ChartType2 = new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000) + new Random().Next(100, 2000);
                }
            }
        }

        private void GetChartType3(ref MeterDetails details)
        {
            if (details.IsIndividual)
            {
                details.ChartType3 = new Random().Next(500, 1500);
            }
            else if (details.IsGroup)
            {
                if (details.IsGroup1)
                {
                    details.ChartType3 = new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500);
                }
                else if (details.IsGroup2)
                {
                    details.ChartType3 = new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500);
                }
                else if (details.IsGroup3)
                {
                    details.ChartType3 = new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500) + new Random().Next(500, 1500);
                }
            }
        }

    }
}